print("*"*10,"Justice League","*"*10)
a = input("Masukkan username anda :")

if ():
    print("===== WELCOME",a,"=====")
    one = print("1. Tambah Angoota Justice League")
    two = print("2. Hapus Anggota JUtstice league")
    three = print("3. Tampilkan Anggota Justice League")
    four = print("exit")

masuk = int(input("Masukkan Pilihan anda :"))

print("*"*10,"Justice League","*"*10)
a = input("Masukkan username anda :")
if (a):
    print("Access Denied")
 
if(masuk ==1): 
    onee = input("Nama Anggota Baru :")
    print("data","'",onee,"'", "berhasil ditambahkan")


