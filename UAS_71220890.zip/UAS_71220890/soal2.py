print("===== Selamat datang di XXV =====")
a = int(input("Masukan tanggal hari ini:"))
b = 25000
if(a==12):
    print("== Berikut genre film yang tersedia ==")
    print("1.Horror")
    print("2.Action")
    input("silahkan pilih mau nonton film yang bergenre apa :")
    print("== berikut pilihan film Horror yang sedang tayang ==")
    print("1. The Devil's Light")
    print("2. Pengabdi setan")
    input("Silahkan pilih mau nonton film apa :")
    tiket = int(input("mau memesan tiket sebanyak :"))
    print("Total yang harus  dibayar adalah Rp. ",b*tiket*2/100)

print("===== Selamat datang di XXV =====")
a = int(input("Masukan tanggal hari ini:"))
    
if(a==5):
    print("== Berikut genre film yang tersedia ==")
    print("1.Horror")
    print("2.Action")
    input("silahkan pilih mau nonton film yang bergenre apa :")
    print("== berikut pilihan film Action yang sedang tayang ==")
    print("1. Black Panther: wakanda forever")
    print("2. Avatar: The Way of water")
    input("Silahkan pilih mau nonton film apa :")
    tiket = int(input("mau memesan tiket sebanyak :"))
    print("Total yang harus  dibayar adalah Rp. ",b*tiket*(5/100))